################ BACA SAYA ########
Ini merupakan file Read.me, Baca file ini dengan baik sehingga tidak ada
kesalahan dalam melakukan kompilasi file latex anda.

Template ini dibuat/disesuaikan untuk JIKO.
Dipersiapkan dalam bahasa Indonesia, Bila anda menghendaki penulisan dalam bahasa internasional
kami sangat menganjurkannya.

JANGAN HAPUS FILE:
1. JIKOlogo.png
2. jiko-logo.pdf
3. jiko-logo.png
4. IEEEtrans.bst
5. CROSSMARK_Color.png
dan
5. JIKO.cls

Anda dapat merubah isi file reference.bib sesuai dengan referensi yang anda gunakan.

################################################################################### 